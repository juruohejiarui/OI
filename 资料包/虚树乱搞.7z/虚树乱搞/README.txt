因为文件系统缘故，可能有一些意义不明的文件，请见谅。

只需要关注下面的文件和文件夹就好了。
./蒟蒻讲虚树.md: markdown博客（这里少了那道分块题）
./蒟蒻讲虚树.pptx: PPT，题目完整
./Images/...: 蒟蒻讲虚树.md的配套图片
./Codes/...: PPT中的例题代码（常数极大）

一些网址：
虚树练习题单：
https://www.luogu.com.cn/training/10666
网上的博客：
CSDN（可能看不到）：https://blog.csdn.net/juruo_hejiarui/article/details/106410597
Cnblogs：https://www.cnblogs.com/juruohjr/p/12982918.html