#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>

using namespace std;

const int maxn = 1e5 + 5, INF = 1e8;

int n, fa[maxn], ch[maxn][2], rev[maxn], val[maxn], minw[maxn], stk[maxn];

#define LS(x) (ch[x][0])
#define RS(x) (ch[x][1])
#define GET(x) (ch[fa[x]][1] == x)
#define ISROOT(x) (ch[fa[(x)]][0] != (x) && ch[fa[(x)]][1] != (x))

void push_up(int x) {
    minw[x] = min(minw[LS(x)], min(minw[RS(x)], val[x]));
}

void rotate(int x) {
  int y = fa[x], z = fa[y], k = GET(x);
  if (!ISROOT(y)) ch[z][ch[z][1] == y] = x;
  ch[y][k] = ch[x][!k], fa[ch[x][!k]] = y;
  ch[x][!k] = y, fa[y] = x, fa[x] = z;
  push_up(x), push_up(y);
}

void splay(int x, int limit = -1) {
    while (!ISROOT(x) && fa[x] != limit) {
        int f = fa[x];
        if (GET(x) == GET(f) && !ISROOT(f) && fa[f] != limit)
            rotate(f);
        rotate(x);
    }
    push_up(x);
}

int access(int x) {
    int p;
    for (p = 0; x; p = x, x = fa[x])
        splay(x), ch[x][1] = p, push_up(x);
    return p;
} 
int main() {
    memset(val, 0x3f, sizeof(val));
    memset(minw, 0x3f, sizeof(minw));
    // freopen("test.in", "r", stdin);
    // freopen("test.out", "w", stdout);
    int n, m, lastans = 0; scanf("%d%d", &n, &m);
    for (int i = 1; i <= m; i++) {
        int t, a, b, c; scanf("%d%d%d", &t, &a, &b);
        a = (a + lastans) % n + 1;
        b = (b + lastans) % n + 1;
        if (!t) {
            scanf("%d", &c);
            c = (c + lastans) % n + 1;
            access(a), splay(a), val[a] = c;
            push_up(a), fa[a] = b;
        } else {
            access(a), splay(b), splay(a, b);
            if (ch[b][1] == a)
                printf("%d\n", lastans = min(val[a], minw[ch[a][0]]));
            else printf("0\n"), lastans = 0;
        }
    }
    return 0;
}