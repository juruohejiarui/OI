#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>
#define LL long long

using namespace std;

const int maxn = 55;
const LL MOD = 998244353;

LL pri[maxn], c, m;

LL qpow(LL a, LL b, LL mod) {
    LL ret = 1;
    while (b) {
        if (b & 1) ret = ret * a % mod;
        a = a * a % mod, b >>= 1;
    }
    return ret;
}

void solve() {
    scanf("%lld%lld", &c, &m);
    LL n = 1, ans = 0;
    for (int i = 1; i <= c; i++) scanf("%lld", &pri[i]), n *= pri[i];
    for (int i = 1; i <= n; i++) {
        LL calc = qpow(i, m, n) - i;
        if (calc % n == 0) ans++, ans %= MOD;
    }
    printf("%lld\n", ans);
}

int main() {
    // freopen("test.in", "r", stdin);
    // freopen("test.out", "w", stdout);
    int id, T; scanf("%d%d", &id, &T);
    while (T--) solve();
    return 0;
}