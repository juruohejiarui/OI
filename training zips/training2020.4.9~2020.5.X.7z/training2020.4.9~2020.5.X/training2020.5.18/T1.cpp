#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>

#define LL long long

using namespace std;

const int maxn = 1e7 + 5;
const LL MOD = 998244353;

LL a, b[maxn], c[maxn], f[maxn], inv[maxn];
int n;

inline LL M(int i) { return min(c[i], b[max(i-1, 0)]); }

void mk_data() {
    LL bx, by, cx, cy, p;
    scanf("%lld%lld%lld%lld%lld", &bx, &by, &cx, &cy, &p);
    b[0] = by + 1, c[0] = cy + 1;
    for (int i = 1; i <= n; i++) {
        b[i] = (b[i-1] * bx + by) % p + 1;
        c[i] = (c[i-1] * cx + cy) % p + 1;
    }
}
int main() {
    freopen("test.in", "r", stdin);
    freopen("test.out", "w", stdout);
    scanf("%d%lld", &n, &a);
    // printf("%lf\n", ((double)(sizeof(f) * 3)) / (1 << 20));
    mk_data();
    inv[1] = 1;
    for (int i = 2; i < maxn; i++) 
        inv[i] = (MOD - MOD / i) * inv[MOD % i] % MOD;
    f[0] = a;
    for (int i = 1; i <= n; i++) {
        LL E = c[i-1] * inv[M(i-1)] % MOD;
        f[i] = E * f[i-1] % MOD + f[max(i-2, 0)];
        f[i] %= MOD;
    }
    printf("%lld\n", f[n]);
    return 0;
}