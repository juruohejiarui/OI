#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <map>
#define LL long long

using namespace std;

const int maxn = 4e6 + 5;
int spl_cnt, m;
LL n, k;

int pri[500005], vis[maxn], pri_cnt;
int phi[maxn];

map<LL, LL> cnt;
map< pair<int,int>,LL > spline;

pair<LL, LL> line[10005];
int line_cnt;

LL gcd(LL a, LL b) { return b ? gcd(b, a % b) : a; }

void get_phi() {
    for (int i = 2; i < maxn; i++) {
        if (!vis[i]) pri[++pri_cnt] = i, phi[i] = i - 1;
        for (int j = 1; j <= pri_cnt && i * pri[j] < maxn; j++) {
            vis[i * pri[j]] = 1;
            if (i % pri[j] == 0) {
                phi[i * pri[j]] = phi[i] * pri[j];
                break;
            }
            phi[i * pri[j]] = phi[i] * phi[pri[j]];
        }
    }
}

void solve() {
    cnt.clear(), spline.clear();
    scanf("%lld%lld%d", &n, &k, &m);
    for (int i = 1; i < n; i++)
        cnt[(n-1)/i] += phi[i] * 2ll;
    cnt[n-1] = 3;
    LL ans = 0;
    for (int i = 1; i <= m; i++) {
        int x, y, g, val; scanf("%d%d", &x, &y);
        if (!x || !y) { 
            if (!x) y = 1;
            else x = 1;
            val = n - 1;
        } else {
            g = gcd(x, y);
            x /= g, y /= g;
            val = (n-1) / max(x, y);
        }
        pair<int, int> p = make_pair(x, y);
        if (spline.count(p)) spline[p]--;
        else {
            cnt[val]--;
            spline[p] = val - 1;
        }
    }
    for (map<pair<int,int>, LL>::iterator it = spline.begin(); it != spline.end(); it++)
        cnt[it->second]++;
    line_cnt = 0;
    for (map<LL, LL>::iterator it = cnt.begin(); it != cnt.end(); it++)
        line[++line_cnt] = *it;
    for (int i = line_cnt; i >= 1 && k > 0; i--) {
        if (k >= line[i].second) {
            k -= line[i].second;
            ans += line[i].first * line[i].second;
        } else {
            ans += k * line[i].first;
            k = 0;
        }
    }
    printf("%lld\n", ans);
}

int main() {
    // freopen("test.in", "r", stdin);
    // freopen("test.out", "w", stdout);
    get_phi();
    int T;
    scanf("%d", &T);
    while (T--) solve();
    
    return 0;
}