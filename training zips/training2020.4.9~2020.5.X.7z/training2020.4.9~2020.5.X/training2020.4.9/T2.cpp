#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>

using namespace std;

const int maxn = 1e5 + 5;
int n, a[maxn], l1[maxn], l2[maxn], blg[maxn], l1_n, l2_n;

bool make_list(int fir, int sec) {
    memset(blg, 0, sizeof(blg));
    int v1 = -1, v2 = -1, to = 0;
    bool succ = true;
    l1_n = l2_n = 0;
    l1[++l1_n] = a[fir], l1[++l1_n] = a[sec], v1 = a[sec] - a[fir];
    blg[fir] = blg[sec] = 1;

    for (int i = sec + 1; i <= n; i++) {
        if (a[i] - l1[l1_n] == v1) l1[++l1_n] = a[i], blg[i] = 1;
        else l2[++l2_n] = a[i], blg[i] = 2;
        if (l2_n == 2) {
            v2 = l2[2] - l2[1];
            if (!v2 || v2 > v1) continue;
            if (v1 % v2 == 0 && (l2[1] - l1[l1_n]) % v2 == 0) {
                to = i;
                break;
            }
        }
        // printf("----\n v1= %d  ", v1);
        // for (int i = 1; i <= l1_n; i++) printf("%d ", l1[i]);
        // putchar('\n');
        // printf("v2= %d ", v2);
        // for (int i = 1; i <= l2_n; i++) printf("%d ", l2[i]);
        // putchar('\n');
    }
    if (to) {
        for (int i = to+1; i <= n; i++)
            if (a[i] - l2[l2_n] == v2) l2[++l2_n] = a[i], blg[i] = 2;
        l1_n = 0;
        for (int i = 1; i <= n; i++) if (blg[i] != 2) l1[++l1_n] = a[i];
    }
    for (int i = 2; i <= l1_n; i++) if (l1[i] - l1[i-1] != v1) {
        succ = false;
        break;
    }
    for (int i = 2; i <= l2_n; i++) if (l2[i] - l2[i-1] != v2) {
        succ = false;
        break;
    }
    if (!succ) {
        succ = true;
        l2[++l2_n] = l1[l1_n], l1_n--;
        sort(l2 + 1, l2 + 1 + l2_n);
        for (int i = 2; i <= l2_n; i++) if (l2[i] - l2[i-1] != v2) {
            succ = false;
            break;
        }
    }
    
    if (succ) {
        if (l1_n == n) {
            l2[++l2_n] = l1[l1_n];
            l1_n--;
        }
        printf("%d\n", l1_n);
        for (int i = 1; i <= l1_n; i++) printf("%d ", l1[i]);
        printf("\n%d\n", l2_n);
        for (int i = 1; i <= l2_n; i++) printf("%d ", l2[i]);
        return true;
    }
    return false;
}
int main() {
    // freopen("test.in", "r", stdin);
    // freopen("test.out", "w", stdout);
    scanf("%d", &n);
    for (int i = 1; i <= n; i++) scanf("%d", &a[i]);
    sort(a + 1, a + 1 + n);
    if (make_list(1,2) || make_list(1,3) || make_list(2,3)) return 0;
    printf("-1\n");
    return 0;
}