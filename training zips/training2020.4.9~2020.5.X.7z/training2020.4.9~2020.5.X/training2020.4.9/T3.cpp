#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>

using namespace std;

const int maxn = 1e6 + 5, maxm = 2e6 + 5;
int n, m, to[maxm][2], cnt[maxm], nd_cnt;
bool fl[maxm];

void insert(int val) {
    int u;
    for (u = 0; val; val >>= 1) {
        int w = val & 1;
        if (!to[u][w]) to[u][w] = ++nd_cnt;
        u = to[u][w];
        cnt[u]++;
    }
    fl[u] = true;
}

int match(int val) {
    int ans = 0, dep = 0, u = 0;
    // printf("match %d\n", val);
    while (!fl[u]) {
        int w = val & 1; val >>= 1;
        // printf("to %d w = %d\n", u, w);
        if (w == 1) u = to[u][1], ans += (1 << dep);
        else {
            if (to[u][0] && cnt[to[u][0]]) u = to[u][0];
            else u = to[u][1], ans += (1 << dep);
        }
        cnt[u]--, dep++;
    }
    fl[u] = false;
    return ans;
}

int main() {
    // freopen("test.in", "r", stdin);
    // freopen("test.out", "w", stdout);
    scanf("%d%d", &n, &m);
    for (int i = m; i < n + m; i++) insert(i);
    for (int i = 0; i < n; i++) {
        int ans = match(i);
        printf("%d %d\n", i, ans);
    }
    return 0;
}