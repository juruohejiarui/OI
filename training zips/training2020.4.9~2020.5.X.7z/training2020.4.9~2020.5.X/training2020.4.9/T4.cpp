#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <set>
#define LL long long

using namespace std;

const int maxn = 5e4 + 5;
const LL MOD = 1e9 + 7, A = 27;
struct Edge {
    int v, nxt;
    Edge() {}
    Edge(int v, int nxt) : v(v), nxt(nxt) {}
} E[maxn << 1];

int hd[maxn], tote;
void addedge(int u, int v) {
    E[++tote] = Edge(v, hd[u]), hd[u] = tote;
    E[++tote] = Edge(u, hd[v]), hd[v] = tote;
}

char ch[maxn];
int n, wrt, wrt_sz, S, sz[maxn], dep[maxn];
bool fl[maxn];
LL hs1[maxn], hs2[maxn], powA[maxn];

inline LL id(char ch) { return (LL)ch - 'a' + 1; }

void get_wroot(int u, int fa) {
    sz[u] = 1;
    int mx_sz = 0;
    for (int i = hd[u]; i; i = E[i].nxt) {
        int v = E[i].v;
        if (v == fa || fl[v]) continue;
        get_wroot(v, u), sz[u] += sz[v];
        mx_sz = max(mx_sz, sz[v]);
    }
    mx_sz = max(mx_sz, S - sz[u]);
    if (mx_sz < wrt_sz) wrt = u, wrt_sz = mx_sz;
}

void get_hash(int u, int fa) {
    sz[u] = 1;
    dep[u] = dep[fa] + 1;
    hs1[u] = (hs1[fa] * A % MOD + id(ch[u])) % MOD;
    hs2[u] = (hs2[fa] + id(ch[u]) * powA[dep[u] - 2] % MOD) % MOD;
    // printf("[%3d] [1]=%8lld, [2]=%8lld\n", u, hs1[u], hs2[u]);
    for (int i = hd[u]; i; i = E[i].nxt) {
        int v = E[i].v;
        if (v == fa || fl[v]) continue;
        get_hash(v, u);
        sz[u] += sz[v];
    } 
}
int ans, tryX, v_ls_n, chk_id, chkt[maxn];
int v_ls_dep[maxn];
LL v_ls_val[maxn];
set<LL> v_set[maxn];
bool succ;

void calc_val(int u, int fa) {
    if (dep[u] > tryX) return ;
    int to_dep = tryX + 1 - dep[u];
    LL val = (hs2[u] * powA[to_dep] % MOD - hs1[u] + MOD) % MOD;
    // printf("[%d] dep=%3d, val=%9lld, 对应dep=%d\n", u, dep[u], val, to_dep);
    if (chkt[to_dep] == chk_id && v_set[to_dep].count(val)) {
        succ = true;
        return ;
    }
    v_ls_n++, v_ls_dep[v_ls_n] = dep[u], v_ls_val[v_ls_n] = val;
    for (int i = hd[u]; i; i = E[i].nxt) {
        int v = E[i].v;
        if (fl[v] || fa == v) continue;
        calc_val(v, u);
        if (succ) return ;
    }
}

bool check(int u, int x) {
    // printf("check %d\n", x);
    tryX = x, succ = false;
    chkt[1] = chk_id;
    v_set[1].clear();
    v_set[1].insert((hs2[u] * powA[tryX] % MOD - hs1[u] + MOD) % MOD);
    // printf("[%d] val=%9lld\n", u, (hs2[u] * powA[tryX] % MOD - hs1[u] + MOD) % MOD);
    for (int i = hd[u]; i; i = E[i].nxt) {
        int v = E[i].v;
        if (fl[v]) continue;
        v_ls_n = 0, calc_val(v, u);
        if (succ) return true;
        for (int j = 1; j <= v_ls_n; j++) {
            if (chkt[v_ls_dep[j]] != chk_id) 
                v_set[v_ls_dep[j]].clear(),
                chkt[v_ls_dep[j]] = chk_id;
            v_set[v_ls_dep[j]].insert(v_ls_val[j]);
        }
    }
    chk_id++;
    return false;
}

void divide(int u) {
    fl[u] = true;
    get_hash(u, -1);
    for (int i = hd[u]; i; i = E[i].nxt) {
        int v = E[i].v;
        if (fl[v]) continue;
        S = sz[v], wrt_sz = 99999999;
        // printf("divide S=%d\n", S);
        if (sz[v] <= ans) continue;
        get_wroot(v, -1), divide(wrt);
    }
    dep[u] = 1, hs1[u] = id(ch[u]), hs2[u] = 0;
    sz[u] = 1;
    for (int i = hd[u]; i; i = E[i].nxt) {
        int v = E[i].v;
        if (fl[v]) continue;
        get_hash(v, u), sz[u] += sz[v];
    }
    S = sz[u];
    //奇数
    int l = (ans+2)/2, r = ceil(S / 2.0);
    while (l <= r) {
        int mid = (l + r) >> 1;
        if (check(u, 2 * mid - 1)) l = mid + 1, ans = max(ans, 2 * mid - 1);
        else r = mid - 1;
    }
    //偶数
    l = (ans+1)/2, r = S / 2;
    while (l <= r) {
        int mid = (l + r) >> 1;
        if (check(u, 2 * mid)) l = mid + 1, ans = max(ans, 2 * mid);
        else r = mid - 1;
    }
    fl[u] = false;
}

int main() {
    // freopen("test.in", "r", stdin);
    // freopen("test.out", "w", stdout);
    scanf("%d\n%s\n", &n, ch + 1);
    powA[0] = 1;
    for (int i = 1; i <= n; i++) powA[i] = powA[i-1] * A % MOD;
    for (int i = 1; i < n; i++) {
        int u, v; 
        scanf("%d%d", &u, &v);
        addedge(u, v);
    }
    ans = 1;
    wrt_sz = 99999999, S = n;
    get_wroot(1, -1), divide(wrt);
    printf("%d\n", ans);
    return 0;
}