#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>

using namespace std;

const int maxn = 1e2 + 5, maxm = 2505, maxk = 1e4 + 5, INF = 1e9;
int n, l, r, m, K, f[maxn][maxk], g[maxn][maxk];

struct Element {
    int val, pos;
    Element(int val = 0, int pos = 0) : val(val), pos(pos) {}
} a[maxn], b[maxn];

int a_sz, b_sz;

int dist(int i, int j) { return abs(a[i].pos - b[j].pos); }

void set_INF(int arr[][maxk], int sz1, int sz2) {
    for (int i = 0; i <= sz1; i++)
        for (int j = 0; j <= sz2; j++)
            arr[i][j] = INF;
}

int main() {
    // freopen("test.in", "r", stdin);
    // freopen("test.out", "w", stdout);
    scanf("%d%d%d%d", &n, &l, &r, &K);
    for (int i = 1; i <= n; i++) {
        int val; scanf("%d", &val);
        if (l <= i && i <= r) a[++a_sz] = Element(val, i);
        else b[++b_sz] = Element(val, i);
    }
    m = r-l+1;
    set_INF(f, n-m, K);
    for (int i = 1; i <= n; i++) {
        for (int j = 0; j <= n-m; j++) {
            for (int k = 0; k <= K; k++) {
                f[j][k] = g[j][k] + a[i].val;
                if (j && k >= dist(i,j)) 
                    f[j][k] = min(f[j][k], g[j-1][k-dist(i,j)] + b[j].val);
            }
        }
        for (int j = 0; j <= n-m; j++) {
            for (int k = 0; k <= K; k++) {
                g[j][k] = f[j][k];
                if (j) g[j][k] = min(g[j][k], g[j-1][k]);
                if (k) g[j][k] = min(g[j][k], g[j][k-1]);
            }
        }
    }
    printf("%d\n", g[n-m][K]);
    return 0;
}