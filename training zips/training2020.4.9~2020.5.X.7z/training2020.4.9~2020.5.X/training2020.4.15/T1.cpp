#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>
#define LL long long
#define FOR(i,st,ed) for (int i = (st); i <= (ed); i++)

using namespace std;

const int maxn = 50, maxm = 200;
const LL MOD = 1234567891;
int a[maxn], n, m;
LL f[maxn][maxm][maxm], inv[maxm], fac[maxm], ifac[maxm];

void get_fac() {
    fac[0] = inv[1] = ifac[0] = 1;
    for (int i = 1; i <= m; i++) fac[i] = fac[i-1] * i % MOD;
    for (int i = 2; i <= m; i++) inv[i] = (MOD - MOD/i) * inv[MOD % i] % MOD;
    for (int i = 1; i <= m; i++) ifac[i] = ifac[i-1] * inv[i] % MOD;
}

LL C(LL a, LL b) { return fac[a] * ifac[b] % MOD * ifac[a-b] % MOD; }
LL P(LL a, LL b) { return fac[a] * ifac[a-b] % MOD; }
void ADD(LL& a, LL b) { a = (a + b) % MOD; }

int main() {
    // freopen("test.in", "r", stdin);
    // freopen("test.out", "w", stdout);
    scanf("%d", &n), m = (n << 2);
    for (int i = 1; i <= n; i++) scanf("%d", &a[i]);
    get_fac();
    f[0][0][0] = 1;
    int sum = 0;
    FOR (i, 0, n-1) {
        FOR (j, 0, 4*i) FOR (k, 0, sum) {
            FOR (x,0,min(k,4)) FOR (y,0,min(j,a[i+1])) {
                LL val = f[i][j][k] * C(k,x) % MOD * P(4,x) % MOD * C(j,y) % MOD * P(a[i+1],y) % MOD;
                ADD(f[i+1][j+(4-x)-y][k-x+(a[i+1]-y)], val);
            }
        }
        sum += a[i+1];
    }
    printf("%lld\n", f[n][m-sum][0]);
    return 0;
}