#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#include <string>
#include <cmath>

using namespace std;

const int maxn = 200005;

#pragma region Trie
struct TrieNode {
    TrieNode* to[2];
    int fl;
    TrieNode() {
        to[0] = to[1] = NULL;
        fl = maxn;
    }
};

void insert(TrieNode* rt, int val, int time) {
    TrieNode* u = rt;
    for (int i = 31; i >= 1; i--) {
        int v = (val >> (i-1)) & 1;
        if (u->to[v] == NULL) u->to[v] = new TrieNode();
        u = u->to[v];
        u->fl = min(u->fl, time);
    }
}

int find_max(TrieNode* rt, int val, int time) {
    TrieNode* u = rt;
    int ans = 0;
    for (int i = 31; i >= 1; i--) {
        int v = (val >> (i-1)) & 1;
        if (u->to[v^1] != NULL && u->to[v^1]->fl <= time) 
            u = u->to[v^1], ans += (1 << (i-1));
        else u = u->to[v];
    }
    return ans;
}

TrieNode* merge_trienode(TrieNode* a, TrieNode* b) {
    if (a == NULL) return b;
    if (b == NULL) return a;
    a->to[0] = merge_trienode(a->to[0], b->to[0]);
    a->to[1] = merge_trienode(a->to[1], b->to[1]);
    a->fl = min(a->fl, b->fl);
    delete b;
    return a;
}

#pragma endregion

int ans[maxn];
struct Query {
    int a, t;
    Query() {}
    Query(int a, int t) : a(a), t(t) {}
};
struct Node {
    int xor_s, t, fat;
    TrieNode* root;
    vector<Query> q;
} nd[maxn];
struct Edge {
    int v, nex;
    Edge() {}
    Edge(int v, int nex) : v(v), nex(nex) {}
} E[maxn];

int hd[maxn], tote;

void addedge(int u, int v) {
    E[++tote] = Edge(v, hd[u]), hd[u] = tote;
}

int vis[maxn], que[maxn], ql, qr;

void bfs() {
    que[ql = qr = 1] = 1;
    while (ql <= qr) {
        int u = que[ql]; ql++;
        for (int i = hd[u]; i; i = E[i].nex) {
            int v = E[i].v;
            if (vis[v]) continue;
            vis[v] = true;
            que[++qr] = v;
        }
    }
    for (int i = qr; i >= 1; i--) {
        int u = que[i];
        nd[u].root = new TrieNode;
        insert(nd[u].root, nd[u].xor_s, nd[u].t);
        for (int j = hd[u]; j; j = E[j].nex) {
            int v = E[j].v;
            if (v == nd[u].fat) continue;
            nd[u].root = merge_trienode(nd[u].root, nd[v].root);
        }
        for (int j = 0; j < nd[u].q.size(); j++)
            ans[nd[u].q[j].t] = find_max(nd[u].root, nd[nd[u].q[j].a].xor_s, nd[u].q[j].t);
    }
}

int main() {
    // freopen("test.in", "r", stdin);
    // freopen("test.out", "w", stdout);
    int T, tot = 1; scanf("%d\n", &T);
    for (int i = 1; i <= T; i++) {
        ans[i] = -1;
        string cmd; int a, b;
        cin >> cmd;
        scanf("%d%d", &a, &b);
        if (cmd[0] == 'A') {
            addedge(a, tot+1), tot++;
            nd[tot].xor_s = nd[a].xor_s ^ b, nd[tot].t = i, nd[tot].fat = a;
        } else
            nd[b].q.push_back(Query(a, i));
    }
    bfs();
    for (int i = 1; i <= T; i++) 
        if (ans[i] != -1) printf("%d\n", ans[i]);
    return 0;
}
