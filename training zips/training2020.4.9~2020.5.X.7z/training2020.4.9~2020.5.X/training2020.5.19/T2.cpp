#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <ctime>
#include <queue>

using namespace std;

const int maxn = 55, INF = 1e8;
const double delta = 0.997;

int n, m, k, is_alr[maxn], alr[maxn], cho[maxn], cho_sz, ans;
struct Edge {
    int v, w, nex;
    Edge() {}
    Edge(int v, int w, int nex) : v(v), w(w), nex(nex) {}
} E[maxn << 1];
int hd[maxn], tote;

void addedge(int u, int v, int w) {
    E[++tote] = Edge(v, w, hd[u]), hd[u] = tote;
    E[++tote] = Edge(u, w, hd[v]), hd[v] = tote;
}

int dist[maxn][maxn];

int calc() {
    int ret = 0;
    for (int i = 1; i <= n; i++) {
        int min_dist = INF;
        for (int j = 1; j <= m; j++) 
            min_dist = min(min_dist, dist[alr[j]][i]);
        for (int j = 1; j <= k; j++)
            min_dist = min(min_dist, dist[cho[j]][i]);
        ret = max(ret, min_dist);
    }
    return ret;
}

void SA() {
    for (double T = 5e3; T > 1e-14; T *= delta) {
        int a = rand() % k + 1, b = rand() % (cho_sz - k) + 1;
        swap(cho[a], cho[k + b]);
        int t = calc(), del = t - ans;
        if (del < 0) ans = t;
        else if (exp(-del / T) * RAND_MAX > rand()) ans = t;
        else swap(cho[a], cho[k + b]);
    }
}

int main() {
    srand(time(NULL)), srand(rand()), srand(rand());
    // freopen("test.in", "r", stdin);
    // freopen("test.out", "w", stdout);
    
    scanf("%d%d%d", &n, &k, &m);
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++) dist[i][j] = INF;
    for (int i = 1; i <= n; i++) dist[i][i] = 0;
    for (int i = 1; i <= n; i++) {
        int v, l; scanf("%d%d", &v, &l), v += 1;
        dist[i][v] = dist[v][i] = min(dist[v][i], l);
    }
    for (int i = 1; i <= m; i++) {
        scanf("%d", &alr[i]), alr[i] += 1;
        is_alr[alr[i]] = 1;
    }
    for (int i = 1; i <= n; i++)
        if (!is_alr[i]) cho[++cho_sz] = i;

    for (int k = 1; k <= n; k++)
        for (int i = 1; i <= n; i++)
            for (int j = 1; j <= n; j++) 
                dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j]);
    ans = calc();
    if (m + k == n) {
        printf("%d\n", calc());
        return 0;
    }
    int a = 4;
    while (a--) SA();
    printf("%d\n", ans);
    return 0;
}