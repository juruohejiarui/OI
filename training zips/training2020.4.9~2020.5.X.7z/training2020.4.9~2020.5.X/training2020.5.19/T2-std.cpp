#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstdlib>
#include<cmath>
	using namespace std;
	const int INF=1e9;
	const double DeltaT=0.997;
	const double Mn=1e-14;
	int n=0,k=0,m=0,cnt=0,AnsW=0;
	int s[55],f[55][55];
	bool c[55];
int Calc()
{
	int ans=0;
	for(int i=0;i<=n-1;i++)
	{
		int MnDis=INF;
		for(int j=0;j<=n-1;j++)
			if(c[j]) MnDis=min(MnDis,f[i][j]);
		ans=max(ans,MnDis);
	}
	return ans;
}
void SA()
{
	int Ans=AnsW;
	double T=5000;
	while(T>Mn)
	{
		int a=rand()%k+1;
		int b=rand()%(cnt-k)+k+1;
		c[s[a]]=false,c[s[b]]=true,swap(s[a],s[b]);
		int Ans0=Calc();
		int Delta=Ans-Ans0;
		AnsW=min(AnsW,Ans0);
		if(Delta>0)
			Ans=Ans0;
		else if(rand()<exp(Delta/T)*RAND_MAX)
			Ans=Ans0;
		else swap(s[a],s[b]),c[s[a]]=true,c[s[b]]=false;
		T*=DeltaT; 
	}
}
int main()
{
	srand(2333);
	scanf("%d%d%d",&n,&k,&m);
	for(int i=0;i<=n-1;i++)
		for(int j=0;j<=n-1;j++)
			f[i][j]=(i==j)?0:INF;
	for(int i=0;i<=n-1;i++)
	{
		int j=0,w=0;
		scanf("%d%d",&j,&w);
		f[i][j]=f[j][i]=min(f[i][j],w);
	}
	for(int l=0;l<=n-1;l++)
		for(int i=0;i<=n-1;i++)
			for(int j=0;j<=n-1;j++)
				f[i][j]=min(f[i][j],f[i][l]+f[l][j]);
	for(int i=1;i<=m;i++)
	{
		int x=0;
		scanf("%d",&x);
		c[x]=true;
	}
	for(int i=0;i<=n-1;i++)
		if(!c[i]) s[++cnt]=i;
	for(int i=1;i<=k;i++) c[s[i]]=true;
	AnsW=Calc();
	if(cnt!=k) SA(),SA(),SA(),SA();
	printf("%d",AnsW);
	return 0;
}