#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#include <cmath>
#define LL long long

using namespace std;

const int maxn = 55;
int n, k, g[maxn][maxn];
LL mod;

char read_YN() {
    char ch = getchar();
    while (ch != 'Y' && ch != 'N') ch = getchar();
    return ch;
}

struct Matrix {
    int sz;
    LL v[maxn][maxn];
    Matrix() { sz = 0, memset(v, 0, sizeof(v)); }
};
Matrix operator * (Matrix a, Matrix b) {
    Matrix c; 
    c.sz = max(a.sz, b.sz);
    for (int i = 1; i <= c.sz; i++)
        for (int j = 1; j <= c.sz; j++)
            for (int k = 1; k <= c.sz; k++)
                c.v[i][j] += a.v[i][k] * b.v[k][j] % mod,
                c.v[i][j] %= mod;
    return c;
}

Matrix operator ^ (Matrix a, LL b) {
    Matrix c = a;
    b--;
    while (b) {
        if (b & 1) c = c * a;
        a = a * a, b >>= 1;
    }
    return c;
}

Matrix make_matrix(int arr[][maxn], int sz) {
    Matrix m; m.sz = sz;
    for (int i = 1; i <= sz; i++)
        for (int j = 1; j <= sz; j++)
            m.v[i][j] = arr[i][j];
    return m;
}
int main() {
    freopen("test.in", "r", stdin);
    freopen("test.out", "w", stdout);
    scanf("%d%d%lld", &n, &k, &mod);
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            char ch = read_YN();
            g[i][j] = (ch == 'Y');
        }
    }
    n++, g[n][n] = 1;
    LL ans = 0;
    for (int i = 1; i < n; i++) {
        g[i][n] = 1;
        Matrix m = make_matrix(g, n);
        // m.debug();
        m = m ^ k;
        // m.debug();
        ans += (m.v[i][n] - 1 + mod) % mod, ans %= mod;
        g[i][n] = 0;
    }
    printf("%lld\n", ans);
    return 0;
}