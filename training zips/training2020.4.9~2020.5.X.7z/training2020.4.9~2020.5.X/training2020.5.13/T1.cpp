#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>
#define LL long long

using namespace std;

const int maxn = 1e5 + 5;
const LL MOD = 1e9 + 7;

int n, M, K, RT, A[maxn]; 

struct Edge {
    int v, nex;
    Edge(int v = 0, int nex = 0) : v(v), nex(nex) {}
} E[maxn << 1];
int hd[maxn], tote;

void addedge(int u, int v) {
    E[++tote] = Edge(v, hd[u]), hd[u] = tote;
    E[++tote] = Edge(u, hd[v]), hd[v] = tote;
}

int fat[maxn], wson[maxn], sz[maxn], dep[maxn], top[maxn], dfn[maxn], nd[maxn];

void dfs1(int u, int fa) {
    fat[u] = fa, sz[u] = 1;
    for (int i = hd[u]; i; i = E[i].nex) {
        int v = E[i].v;
        if (v == fa) continue;
        dep[v] = dep[u] + 1;
        dfs1(v, u);
        sz[u] += sz[v];
        if (!wson[u] || sz[wson[u]] < sz[v])
            wson[u] = v;
    }
}

int dfn_cnt;
void dfs2(int u, int tp) {
    dfn[u] = ++dfn_cnt, nd[dfn_cnt] = u;
    top[u] = tp;
    if (!wson[u]) return ;
    dfs2(wson[u], tp);
    for (int i = hd[u]; i; i = E[i].nex) {
        int v = E[i].v;
        if (v == fat[u] || v == wson[u]) continue;
        dfs2(v, v);
    }
}

int C[maxn];
#define lowbit(x) ((x) & (-(x)))

void trarr_add(int x, int val) {
    for (; x <= n; x += lowbit(x)) C[x] += val;
}

int trarr_ask(int x) {
    int ret = 0;
    for (; x > 0; x -= lowbit(x)) ret += C[x];
    return ret;
}
void trarr_clear() {
    for (int i = 1; i <= K; i++) trarr_add(dfn[A[i]], -1);
}

int get_cnt(int x, int y) {
    int ret = 0;
    while (top[x] != top[y]) {
        if (dep[top[x]] < dep[top[y]]) swap(x, y);
        ret += trarr_ask(dfn[x]) - trarr_ask(dfn[top[x]] - 1);
        x = fat[top[x]];
    }
    if (dep[x] < dep[y]) swap(x, y); 
    ret += trarr_ask(dfn[x]) - trarr_ask(dfn[y] - 1);
    return ret;
}

int cnt[maxn]; LL f[maxn][305];

bool cmp(int a, int b) {
    return cnt[a] < cnt[b];
}
void solve_query() {
    trarr_clear();
    scanf("%d%d%d", &K, &M, &RT);
    for (int i = 1; i <= K; i++) {
        scanf("%d", &A[i]);
        trarr_add(dfn[A[i]], 1);
    }
    for (int i = 1; i <= K; i++) {
        cnt[A[i]] = get_cnt(RT, A[i]) - 1;
        // printf("%d ", cnt[A[i]]);
    }
    sort(A + 1, A + 1 + K, cmp);
    f[1][1] = 1;
    for (int i = 2; i <= K; i++) {
        for (int j = 1; j <= M && j <= i; j++) {
            if (j >= cnt[A[i]])
                f[i][j] = (f[i-1][j] * (j - cnt[A[i]]) % MOD + f[i-1][j-1]) % MOD;
            else f[i][j] = f[i-1][j-1];
        }
    }
    LL ans = 0;
    for (int i = 1; i <= M; i++) ans = (ans + f[K][i]) % MOD;
    printf("%lld\n", ans);
}

int main() {
    // freopen("test.in", "r", stdin);
    // freopen("test.out", "w", stdout);
    int q;
    scanf("%d%d", &n, &q);
    for (int i = 1; i < n; i++) {
        int u, v; scanf("%d%d", &u, &v);
        addedge(u, v);
    }
    dep[1] = 1, dfs1(1, 0), dfs2(1, 1);
    while (q--) solve_query();
    return 0;
}