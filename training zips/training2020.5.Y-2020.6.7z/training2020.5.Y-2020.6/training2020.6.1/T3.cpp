#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>

using namespace std;

