#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>

using namespace std;

const int maxn = 305, maxm = maxn * 2;

int n, m, s[maxm][maxm], g[maxm][maxm], _g[maxm][maxm], ans;

struct Point {
    int x, y;
} p[maxn * maxn];

Point make_point(int x, int y) {
    Point p; p.x = x, p.y = y;
    return p;   
}
int p_sz;

char read_g() {
    char ch = getchar();
    while (ch != '.' && ch != '*') ch = getchar();
    return ch;
}

void turn_90() {
    p_sz = 0;
    for (int x = 1; x <= n; x++)
        for (int y = 1; y <= n; y++)
            _g[y][n - x + 1] = g[x][y];
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            g[i][j] = _g[i][j];
            if (g[i][j]) p[++p_sz] = make_point(i,j);
        }
    }
}

void find_ans() {
    for (int i = 1; i <= m + 1; i++)
        for (int j = 1; j <= n; j++)
            s[i][j] = s[i-1][j+1] + g[i][j];
    for (int i = 1; i <= p_sz; i++)
        for (int dis = 1, limit = min(n - p[i].x, p[i].y - 1); dis <= limit; dis++) {
            int x1 = p[i].x + dis, y1 = p[i].y - dis;
            if (!g[x1][y1]) continue;
            
            ans += s[p[i].x + 2 * dis][p[i].y] - s[p[i].x + dis][p[i].y + dis];
        }
}

int main() {
    // freopen("test.in", "r", stdin);
    // freopen("test.out", "w", stdout);
    scanf("%d", &n), m = n << 1;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++) {
            char ch = read_g();
            if (ch == '*') g[i][j] = 1, p[++p_sz] = make_point(i,j);
        }
    find_ans();
    turn_90(), find_ans();
    turn_90(), find_ans();
    turn_90(), find_ans();
    printf("%d\n", ans);
    return 0;
}