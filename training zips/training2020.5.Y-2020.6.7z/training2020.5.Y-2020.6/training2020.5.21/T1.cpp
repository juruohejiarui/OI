#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <set>

using namespace std;

const int maxn = 1e5 + 5;

struct Edge {
    int v, nex;
    Edge() {};
    Edge(int v, int nex) : v(v), nex(nex) {}
} E[maxn << 1];

int hd[maxn], tote;
void addedge(int u, int v) {
    E[++tote] = Edge(v, hd[u]), hd[u] = tote;
    E[++tote] = Edge(u, hd[v]), hd[v] = tote;
}

int n;
multiset<int> S[maxn];
bool succ; int tryX, len[maxn];

void dfs(int u, int fa) {
    S[u].clear();
    bool exist_spath = false;
    for (int i = hd[u]; i; i = E[i].nex) {
        int v = E[i].v;
        if (v == fa) continue;
        dfs(v, u);
        if (!succ) return ;
        S[u].insert(len[v] + 1);
    }
    int sz = S[u].size();
    if ((u == 1 && (sz & 1)) || (u != 1 && !(sz & 1))) S[u].insert(0);
    while (!S[u].empty()) {
        multiset<int>::iterator it1, it2;
        int len1;
        it1 = S[u].begin(), len1 = *it1, S[u].erase(it1);
        it2 = S[u].lower_bound(tryX - len1);

        if (u == 1) {
            if (it2 == S[u].end()) { succ = false; break; }
            S[u].erase(it2);
        } else {
            if (it2 == S[u].end()) {
                if (exist_spath) { succ = false; break; }
                else exist_spath = true, len[u] = len1;
            } else S[u].erase(it2);
        }
    }
}

bool check(int X) {
    for (int i = 1; i <= n; i++) len[i] = 0;
    tryX = X, succ = true;
    dfs(1, -1);
    return succ;
}
int main() {
    // freopen("test.in", "r", stdin);
    // freopen("test.out", "w", stdout);
    scanf("%d", &n);
    for (int i = 1; i < n; i++) {
        int u, v; scanf("%d%d", &u, &v);
        addedge(u, v);
    }
    int l = 1, r = n, ans = -1;
    while (l <= r) {
        int mid = (l + r) >> 1;
        if (check(mid)) ans = mid, l = mid + 1;
        else r = mid - 1;
    }
    printf("%d\n", ans);
    return 0;
}