#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int mod=1e9+7,N=16;
int n,m,id,x,y,b[N][N],cnt[1<<15];
ll a2[N*N],f[1<<15],g[1<<15];
int main()
{
//	freopen("winner.in","r",stdin); freopen("winner.out","w",stdout);
	scanf("%d%d%d",&n,&m,&id);
	for(int i=1; i<=m; i++) scanf("%d%d",&x,&y),b[x][y]=b[y][x]=1;
	a2[0]=1;
	for(int i=1; i<=n*n; i++)a2[i]=a2[i-1]*2%mod;
	for(int s=0; s<1<<n; s++)
	{
		for(int i=0; i<n; i++) if(s>>i&1)
		{
			cnt[s]=cnt[s^(1<<i)];
			for(int j=0; j<n; j++) if(s>>j&1) cnt[s]+=b[i+1][j+1];
			break;
		}
	}
	for(int s=0; s<1<<n; s++)
	{
		if(s&1)
		{
			f[s]=a2[cnt[s]];
			for(int t=(s-1)&s; t>0; t=(t-1)&s)
				f[s]=(f[s]-f[t]*a2[cnt[s^t]])%mod;
		}
		if(s&2)
		{
			g[s]=a2[cnt[s]];
			for(int t=(s-1)&s; t>0; t=(t-1)&s)
				g[s]=(g[s]-g[t]*a2[cnt[s^t]])%mod;
		}
	}
	ll ans=a2[m];
	for(int s=0; s<1<<n; s++) if(f[s])
	{
		for(int t=s+1; t<(1<<n); t=(t+1)|s) if(g[s^t])
		{
			int z=(1<<n)-1-t;
			if(cnt[s^z]+cnt[s^t^z]-cnt[z]==m)
			{
				ans=(ans-f[s]*g[s^t]%mod*a2[cnt[z]])%mod;
			}
		}
	}
	ans=(ans%mod+mod)%mod;
	printf("%lld\n",ans);
}