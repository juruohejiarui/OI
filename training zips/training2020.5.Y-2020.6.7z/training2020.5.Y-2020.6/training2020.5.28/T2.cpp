#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>
#define LL long long

using namespace std;

const int maxn = 20, maxm = maxn * maxn;
const LL MOD = 1e9 + 7;
int n, m, id, g[maxn][maxn], Smax;
LL f1[1 << 16], f2[1 << 16], cnt[1 << 16], pow2[maxm];

inline bool inS(int S, int x) { return S & (1 << (x-1)); }
inline int delx(int S, int x) { return S ^ (1 << (x-1)); }
int main() {
    freopen("test.in", "r", stdin);
    freopen("test.out", "w", stdout);
    scanf("%d%d%d", &n, &m, &id), Smax = (1 << n) - 1;
    for (int i = 1; i <= m; i++) {
        int u, v; scanf("%d%d", &u, &v);
        g[u][v] = g[v][u] = 1;
    }
    
    pow2[0] = 1;
    for (int i = 1; i <= n * n; i++) pow2[i] = pow2[i-1] * 2 % MOD;
    for (int S = 0; S <= Smax; S++) {
        for (int i = 1; i <= n; i++) if (inS(S, i)) {
            cnt[S] = cnt[delx(S, i)];
            for (int j = 1; j <= n; j++) if (inS(S, j))
                cnt[S] = (cnt[S] + g[i][j]) % MOD;
            break;
        }
    }
    for (int S = 0; S <= Smax; S++) {
        if (inS(S, 1)) {
            f1[S] = pow2[cnt[S]];
            for (int _S = (S - 1) & S; _S; _S = (_S - 1) & S)
                f1[S] = (f1[S] - f1[_S] * pow2[cnt[S ^ _S]] % MOD + MOD) % MOD;
        }
        if (inS(S, 2)) {
            f2[S] = pow2[cnt[S]];
            for (int _S = (S - 1) & S; _S; _S = (_S - 1) & S) 
                f2[S] = (f2[S] - f2[_S] * pow2[cnt[S ^ _S]] % MOD + MOD) % MOD;
        }
    }
    LL ans = pow2[m];
    for (int S1 = 0; S1 <= Smax; S1++) if (f1[S1]) {
        for (int S = S1+1; S <= Smax; S = (S + 1) | S1) if (f2[S ^ S1]) {
            int S3 = Smax - S;
            if (cnt[S1 ^ S3] + cnt[S ^ S1 ^ S3] - cnt[S3] == m)
                ans = (ans - f1[S1] * f2[S ^ S1] % MOD * pow2[cnt[S3]] % MOD + MOD) % MOD;
        }
    }
    printf("%lld\n", ans);
    return 0;
}