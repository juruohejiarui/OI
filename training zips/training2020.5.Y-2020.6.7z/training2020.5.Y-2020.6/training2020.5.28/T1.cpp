#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>

using namespace std;

const int maxn = 5e5 + 5, MOD = 10000789;
char str[maxn];
int n, hs[maxn], f[2][maxn];
long long fl[MOD + 5];

inline int id(char ch) { return ch - 'a' + 1; }
int main() {
    // freopen("test.in", "r", stdin);
    // freopen("test.out", "w", stdout);
    scanf("%s", str + 1), n = strlen(str + 1);
    int max_len = 2 * sqrt(n) + 3, ans = 1;
    for (int i = 0; i <= n; i++) f[1][i] = 1, hs[i] = id(str[i]);
    for (int len = 2; len <= max_len; len++) {
        bool better = false;
        int t1 = len & 1, t2 = (len - 1) & 1;
        for (int i = n; i >= 1; i--) {
            if (i + len <= n && f[t2][i + len]) fl[hs[i+len]] = 1;
            if (fl[hs[i]] || fl[hs[i+1]])
                f[t1][i] = 1, ans = len, better = true;
            f[t2][i + len] = 0;
        }
        for (int i = 1; i <= n - len + 1; i++) {
            fl[hs[i + len]] = 0;
            hs[i] = (hs[i] * 30 % MOD + id(str[i+len-1])) % MOD;
        }
        if (!better) break;
    }
    printf("%d\n", ans);
    return 0;
}