#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>
#define LL long long

using namespace std;

const int maxn = 2e5 + 5, maxm = 25;
const LL MOD = 1e9 + 7;

struct Query {
    int l, r;
} q[maxn];
int n, ls1[maxn], ls2[maxn];
LL a[maxn], ans_ls[maxn], f[maxn][maxm], mod;

void solve(int l, int r, int lsl, int lsr) {
    if (lsl > lsr) return ;
    int mid = (l + r) >> 1, ls1_p = lsl - 1;
    for (int i = 0; i < mod; i++) f[mid][i] = 0;
    f[mid][0]++;
    for (int i = mid; i < r; i++) {
        for (int j = 0; j < mod; j++)
            f[i + 1][j] = f[i][j];
        for (int j = 0; j < mod; j++)
            f[i + 1][(j + a[i + 1]) % mod] += f[i][j],
            f[i + 1][(j + a[i + 1]) % mod] %= MOD;
    }
    for (int i = 0; i < mod; i++) f[mid][i] = 0;
    f[mid][0]++, f[mid][a[mid] % mod]++;
    for (int i = mid; i > l; i--) {
        for (int j = 0; j < mod; j++)
            f[i - 1][j] = f[i][j];
        for (int j = 0; j < mod; j++)
            f[i - 1][(j + a[i - 1]) % mod] += f[i][j],
            f[i - 1][(j + a[i - 1]) % mod] %= MOD;
    }
    int ls2_sz = 0;
    for (int i = lsl; i <= lsr; i++) {
        int id = ls1[i];
        if (q[id].r <= mid) ls1[++ls1_p] = id;
        else if (q[id].l > mid) ls2[++ls2_sz] = id;
        else {
            LL ans = 0;
            ans += f[q[id].l][0] * f[q[id].r][0] % MOD;
            for (int j = 1; j < mod; j++) {
                ans += f[q[id].l][j] * f[q[id].r][mod - j] % MOD;
                ans %= MOD;
            }
            ans_ls[id] = ans;
        }
    }
    for (int i = 1; i <= ls2_sz; i++) ls1[ls1_p + i] = ls2[i];
    lsr = ls1_p + ls2_sz;
    solve(l, mid, lsl, ls1_p), solve(mid + 1, r, ls1_p + 1, lsr);
}
int main() {
    // freopen("test.in", "r", stdin);
    // freopen("test.out", "w", stdout);
    scanf("%d%lld", &n, &mod);
    int ls1_sz = 0;
    for (int i = 1; i <= n; i++) scanf("%lld", &a[i]);
    int q_sz; scanf("%d", &q_sz);
    for (int i = 1; i <= q_sz; i++) {
        scanf("%d%d", &q[i].l, &q[i].r);
        if (q[i].l == q[i].r) {
            ans_ls[i] = 1 + (a[q[i].l] % mod == 0);
        } else ls1[++ls1_sz] = i;
    }
    solve(1, n, 1, ls1_sz);
    for (int i = 1; i <= q_sz; i++) printf("%lld\n", ans_ls[i]);
    return 0;
}