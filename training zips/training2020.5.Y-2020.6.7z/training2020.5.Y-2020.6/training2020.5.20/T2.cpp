#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>

using namespace std;

const int maxn = 55;
int g[maxn][maxn], dep[maxn], topo[maxn], topo_sz;

int main() {
    // freopen("test.in", "r", stdin);
    // freopen("test.out", "w", stdout);
    printf("-1\n");
    return 0;
}