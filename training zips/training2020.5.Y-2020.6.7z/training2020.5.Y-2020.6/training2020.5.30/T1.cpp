#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>
#define ULL unsigned long long
#define LL long long

using namespace std;

int main() {
    ULL O = 0; LL input_O;
    cin >> input_O;
    if (input_O <= 0) cout << 0 << endl;
    else {
        O = input_O;
        cout << O * 2 - 1 << endl;
    }
    return 0;
}