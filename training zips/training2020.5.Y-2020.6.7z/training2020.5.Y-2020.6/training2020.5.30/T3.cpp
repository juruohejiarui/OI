#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>
#define LL long long

using namespace std;

LL n, ans = 0;

LL gcd(LL a, LL b) { return b ? gcd(b, a % b) : a; }
LL f(LL a) { return a / 2 + a / 5 - a / 10; }
LL g(LL a) { return a - f(a); }
int main() {
    freopen("test.in", "r", stdin);
    freopen("test.out", "w", stdout);
    scanf("%lld", &n);
    for (int i = 1; i <= n; i <<= 1)
        for (int j = i; j <= n; j *= 5) {
            ans += g(j) * g(n / j);
        }
    printf("%lld\n", ans * 2 - 1);
    return 0;
}