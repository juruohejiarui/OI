#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>
#define LL long long

using namespace std;

const int maxn = 1e3 + 5, maxm = 1e6 + 5;
const LL MOD = 998244353;

char read_ch() {
    char ch = getchar();
    while (ch != 'O' && ch != 'X') ch = getchar();
    return ch;
}

struct Edge {
    int v, nex;
    Edge(int v=0, int nex=0) : v(v), nex(nex) {}
} E[maxm << 1];

int hd[maxm], tote;
void addedge(int u, int v) {
    E[++tote] = Edge(v, hd[u]), hd[u] = tote;
    E[++tote] = Edge(u, hd[v]), hd[v] = tote;
}

int n, m, g[maxn][maxn];
bool vis[maxm];
LL len, k, ans, pow_arr[maxm];

inline int id(int x, int y) { return (x-1) * m + y; }

void dfs(int u, int fa) {
    vis[u] = 1, len++;
    for (int i = hd[u]; i; i = E[i].nex) {
        int v = E[i].v;
        if (v == fa) continue;
        if (vis[v]) { ans = 0; continue; }
        dfs(v, u);
    }
}

int main() {
    // freopen("test.in", "r", stdin);
    // freopen("test.out", "w", stdout);
    scanf("%d%d%lld", &n, &m, &k), k %= MOD;
    pow_arr[0] = 1, pow_arr[1] = k;
    for (int i = 2; i <= n * m; i++) pow_arr[i] = pow_arr[i-1] * (k - 1) % MOD;
    for (int i = 1; i <= n; i++) 
        for (int j = 1; j <= m; j++) {
            char ch = read_ch();
            if (ch == 'O') g[i][j] = 1;
            if (g[i][j] == 1) {
                if (g[i-1][j] == 1) addedge(id(i,j), id(i-1, j));
                if (g[i][j-1] == 1) addedge(id(i,j), id(i, j-1));
            }
        }
    ans = 1;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++) if (g[i][j] == 1 && !vis[id(i, j)]) {
            len = 0, dfs(id(i, j), -1);
            ans = ans * pow_arr[len] % MOD;
        }
    printf("%lld\n", ans);
    return 0;
}