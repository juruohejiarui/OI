#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#include <queue>
#include <cmath>
#define LL long long
#define D double

using namespace std;

const int maxn = 105, maxm = 55 * 55;

struct Point {
    LL x, y;
} p[maxn];

inline LL dist(Point p1, Point p2) {
    return (p1.x - p2.x) * (p1.x - p2.x) + (p1.y - p2.y) * (p1.y - p2.y);
}
struct EdgeInfo {
    int u, v; LL w;
    EdgeInfo(int u = 0, int v = 0, LL w = 0) : u(u), v(v), w(w) {}
    friend bool operator < (EdgeInfo a, EdgeInfo b) {
        return a.w < b.w;
    }
} E_info[maxm];

LL dis_ls[maxm * 2]; 
int n, dis_ls_sz, E_info_sz;

struct MaxFlow {
    // S : n+1, T : n+2
    struct Edge {
        int v, w, nex;
        Edge() {}
        Edge(int v, int w, int nex) : v(v), w(w), nex(nex) {}
    } E[maxm << 2];

    int hd[maxn], tote;

    void addedge(int u, int v, int w) {
        E[tote] = Edge(v, w, hd[u]), hd[u] = tote++;
        E[tote] = Edge(u, 0, hd[v]), hd[v] = tote++;
    }

    void destroy() {
        for (int i = 1; i <= n + 2; i++) hd[i] = -1;
        tote = 0;
    }

    int d[maxn], q[maxn], qhd, qtl;

    queue<int> que;
    bool bfs() {
        memset(d, -1, sizeof(d));
        while (!que.empty()) que.pop();
        que.push(n + 1), d[n + 1] = 0;
        while (!que.empty()) {
            int u = que.front(); que.pop();
            for (int i = hd[u]; ~i; i = E[i].nex) {
                int v = E[i].v;
                if (d[v] != -1 || !E[i].w) continue;
                d[v] = d[u] + 1, que.push(v);
            }
        }
        return d[n + 2] != -1;
    }

    int dfs(int u, int dis) {
        if (u == n + 2) return dis;
        for (int i = hd[u]; ~i; i = E[i].nex) {
            int v = E[i].v;
            if (d[u] >= d[v] || !E[i].w) continue;
            int k = dfs(v, min(dis, E[i].w));
            if (k) {
                E[i].w -= k, E[i ^ 1].w += k;
                return k;
            }
        }
        return 0;
    }
    
    int dinic() {
        int ans = 0;
        while (true) {
            if (!bfs()) break;
            int t;
            while (t = dfs(n + 1, 99999999)) ans += t; 
        }
        return ans;
    }
} flow;

void solve() {
    D pi = acos(-1);
    LL R, sq_R;
    int N, M; scanf("%d%d%lld", &N, &M, &R);
    n = N + M, sq_R = R * R * 4, E_info_sz = dis_ls_sz = 0;
    for (int i = 1; i <= N; i++)
        scanf("%lld%lld", &p[i].x, &p[i].y);
    for (int i = 1; i <= M; i++) {
        scanf("%lld%lld", &p[i+N].x, &p[i+N].y);
        
        for (int j = 1; j <= N; j++) {
            LL d = dist(p[j], p[i+N]);
            if (d > sq_R) continue;
            E_info[++E_info_sz] = EdgeInfo(j, i+N, d);
            dis_ls[++dis_ls_sz] = d;
        }
    }
    dis_ls[++dis_ls_sz] = sq_R;

    sort(dis_ls + 1, dis_ls + 1 + dis_ls_sz);
    dis_ls_sz = unique(dis_ls + 1, dis_ls + 1 + dis_ls_sz) - dis_ls - 1;

    sort(E_info + 1, E_info + 1 + E_info_sz);

    int p = 0; D ans = 0;
    for (int i = 1; i <= dis_ls_sz; i++) {
        while (E_info[p + 1].w < dis_ls[i] && p + 1 <= E_info_sz) p++;
        D r = dis_ls[i];
        flow.destroy();
        for (int u = 1; u <= N; u++) flow.addedge(n + 1, u, 1);
        for (int u = N+1; u <= N+M; u++) flow.addedge(u, n + 2, 1);
        for (int j = 1; j <= p; j++) flow.addedge(E_info[j].u, E_info[j].v, 1);
        int cnt = n - flow.dinic();
        ans = max(ans, pi * cnt * r / 4);
    }
    printf("%.7lf\n", ans);
}

int main() {
    freopen("test.in", "r", stdin);
    freopen("test.out", "w", stdout);
    int T; scanf("%d", &T);
    while (T--) solve();
    return 0;
}