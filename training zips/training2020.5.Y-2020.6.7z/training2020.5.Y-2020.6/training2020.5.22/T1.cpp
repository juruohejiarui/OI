#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>

using namespace std;

const int maxn = 250005, maxm = 2505;
struct Point {
    int x, y;
} p[maxn];

int n, min_x[maxm], max_y[maxm], max_x[maxm], min_y[maxm];

int f1[maxm][maxm], f2[maxm][maxm], s1[maxm][maxm], s2[maxm][maxm];

int F1(int x, int y) {
    // printf("F1(%d,%d)\n", x, y);
    if (f1[x][y] >= 0) return f1[x][y];
    if (s1[x][y] < 2) return s1[x][y];
    int nex_x = min(x, min_x[y - 1]), nex_y = max(y, max_y[x + 1]);

    f1[x][y] = s1[x][y] + F1(nex_x, nex_y);
    return f1[x][y];
}

int F2(int x, int y) {
    // printf("F2(%d,%d)\n", x, y);
    if (f2[x][y] >= 0) return f2[x][y];
    if (s2[x][y] < 2) return s2[x][y];
    int nex_x = max(x, max_x[y + 1]), nex_y = min(y, min_y[x - 1]);

    f2[x][y] = s2[x][y] + F2(nex_x, nex_y);
    return f2[x][y];
}

int main() {
    // freopen("test.in", "r", stdin);
    // freopen("test.out", "w", stdout);
    scanf("%d", &n);
    int m = 2500;
    for (int i = 0; i <= m+1; i++) { 
        min_x[i] = min_y[i] = m + 1;
        max_x[i] = max_y[i] = -m - 1;
    }
    for (int i = 1; i <= n; i++) {
        scanf("%d%d", &p[i].x, &p[i].y);
        min_x[p[i].y] = min(min_x[p[i].y], p[i].x);
        max_x[p[i].y] = max(max_x[p[i].y], p[i].x);
        min_y[p[i].x] = min(min_y[p[i].x], p[i].y);
        max_y[p[i].x] = max(max_y[p[i].x], p[i].y);
        s1[p[i].x][p[i].y]++, s2[p[i].x][p[i].y]++;
    }

    for (int i = 1; i <= m; i++)
        for (int j = m; j >= 1; j--)
            s1[i][j] += s1[i-1][j] + s1[i][j+1] - s1[i-1][j+1], 
            f1[i][j] = f2[i][j] = -1;
    for (int i = m; i >= 1; i--)
        for (int j = 1; j <= m; j++)
            s2[i][j] += s2[i][j-1] + s2[i+1][j] - s2[i+1][j-1];
    
    for (int i = 1; i <= m; i++) {
        min_x[i] = min(min_x[i], min_x[i-1]);
        min_y[i] = min(min_y[i], min_y[i-1]);
    }
    for (int i = m; i >= 1; i--) {
        max_x[i] = max(max_x[i], max_x[i+1]);
        max_y[i] = max(max_y[i], max_y[i+1]);
    }
    for (int i = 1; i <= n; i++)
        printf("%d\n", F1(p[i].x, p[i].y) + F2(p[i].x, p[i].y) + n - 3);
    return 0;
}